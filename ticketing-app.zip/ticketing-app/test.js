// End-to-end API test. Run with: npm test
process.env.ADMIN_PASSWORD = 'testpw';
process.env.TICKET_SECRET = 'test-secret';
process.env.DB_FILE = ':memory:';

const assert = require('assert');
const app = require('./server');

const server = app.listen(0, async () => {
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, path, body, pw = 'testpw') => {
    const r = await fetch(base + path, {
      method,
      headers: { 'Content-Type': 'application/json', 'x-admin-password': pw },
      body: body ? JSON.stringify(body) : undefined
    });
    return { status: r.status, body: await r.json().catch(() => ({})) };
  };

  try {
    // auth
    assert.strictEqual((await call('GET', '/api/events', null, 'nope')).status, 401);

    // event + promoter
    const ev = (await call('POST', '/api/events', { name: 'Test Night', price: 100, capacity: 5 })).body;
    const promo = (await call('POST', '/api/promoters', { name: 'Anna', code: 'anna20', discount_percent: 20, commission_percent: 10, max_uses: 3 })).body;
    assert.strictEqual(promo.code, 'ANNA20');
    assert.strictEqual((await call('POST', '/api/promoters', { name: 'Dup', code: 'ANNA20' })).status, 409);

    // generate with promo code: 20% off
    let r = await call('POST', '/api/tickets', { event_id: ev.id, quantity: 2, promo_code: 'anna20', holder_name: 'Jan' });
    assert.strictEqual(r.status, 201);
    assert.strictEqual(r.body.tickets[0].price_paid, 80);
    const [t1, t2] = r.body.tickets;

    // promo usage limit (3 total): 2 used, asking for 2 more must fail
    r = await call('POST', '/api/tickets', { event_id: ev.id, quantity: 2, promo_code: 'ANNA20' });
    assert.strictEqual(r.status, 409);

    // invalid promo code
    assert.strictEqual((await call('POST', '/api/tickets', { event_id: ev.id, promo_code: 'NOPE' })).status, 400);

    // full price ticket
    r = await call('POST', '/api/tickets', { event_id: ev.id, quantity: 1 });
    assert.strictEqual(r.body.tickets[0].price_paid, 100);

    // capacity (5): 3 sold, 3 more must fail
    assert.strictEqual((await call('POST', '/api/tickets', { event_id: ev.id, quantity: 3 })).status, 409);

    // check-in: first scan ok, second already_used
    assert.strictEqual((await call('POST', '/api/check', { code: t1.code })).body.result, 'ok');
    assert.strictEqual((await call('POST', '/api/check', { code: t1.code })).body.result, 'already_used');
    // lowercase / whitespace tolerated
    assert.strictEqual((await call('POST', '/api/check', { code: ' ' + t2.code.toLowerCase() + ' ' })).body.result, 'ok');

    // forged code (bad signature) and garbage
    const forged = t1.code.slice(0, -8) + '00000000';
    assert.strictEqual((await call('POST', '/api/check', { code: forged })).body.result, 'invalid');
    assert.strictEqual((await call('POST', '/api/check', { code: 'hello' })).body.result, 'invalid');

    // cancel
    const t3 = (await call('POST', '/api/tickets', { event_id: ev.id, quantity: 1 })).body.tickets[0];
    assert.strictEqual((await call('POST', `/api/tickets/${t3.code}/cancel`)).status, 200);
    assert.strictEqual((await call('POST', '/api/check', { code: t3.code })).body.result, 'cancelled');

    // promoter stats
    const stats = (await call('GET', '/api/promoters')).body[0];
    assert.strictEqual(stats.tickets_sold, 2);
    assert.strictEqual(stats.revenue, 160);
    assert.strictEqual(stats.commission_owed, 16);

    // QR image
    const qr = await fetch(`${base}/api/tickets/${t1.code}/qr.png`);
    assert.strictEqual(qr.status, 200);
    assert.strictEqual(qr.headers.get('content-type'), 'image/png');
    assert.strictEqual((await fetch(`${base}/api/tickets/${forged}/qr.png`)).status, 404);

    console.log('All tests passed');
    server.close();
  } catch (e) {
    console.error('TEST FAILED:', e);
    server.close();
    process.exit(1);
  }
});
