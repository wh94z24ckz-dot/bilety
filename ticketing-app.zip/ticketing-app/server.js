const express = require('express');
const Database = require('better-sqlite3');
const QRCode = require('qrcode');
const crypto = require('crypto');
const path = require('path');

// ---------- Config ----------
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change-me';
const TICKET_SECRET = process.env.TICKET_SECRET || 'dev-secret-change-me';
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'tickets.db');

if (!process.env.ADMIN_PASSWORD || !process.env.TICKET_SECRET) {
  console.warn('WARNING: using default ADMIN_PASSWORD / TICKET_SECRET. Set them as environment variables in production.');
}

// ---------- Database ----------
const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  venue TEXT,
  date TEXT,
  price REAL NOT NULL DEFAULT 0,
  capacity INTEGER NOT NULL DEFAULT 100,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS promoters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  discount_percent REAL NOT NULL DEFAULT 0,
  commission_percent REAL NOT NULL DEFAULT 0,
  max_uses INTEGER,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  event_id INTEGER NOT NULL REFERENCES events(id),
  promoter_id INTEGER REFERENCES promoters(id),
  holder_name TEXT,
  email TEXT,
  price_paid REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'valid',   -- valid | used | cancelled
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  used_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tickets_event ON tickets(event_id);
CREATE INDEX IF NOT EXISTS idx_tickets_promoter ON tickets(promoter_id);
`);

// ---------- Ticket codes ----------
// Format: TKT-<10 random chars>-<8 hex signature>. The signature lets the scanner
// reject forged codes even before touching the database.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I to avoid typos
function randomId(len) {
  const bytes = crypto.randomBytes(len);
  return Array.from(bytes, b => ALPHABET[b % ALPHABET.length]).join('');
}
function sign(id) {
  return crypto.createHmac('sha256', TICKET_SECRET).update(id).digest('hex').slice(0, 8).toUpperCase();
}
function makeTicketCode() {
  const id = randomId(10);
  return `TKT-${id}-${sign(id)}`;
}
function verifyTicketCode(code) {
  const m = /^TKT-([A-Z0-9]{10})-([A-F0-9]{8})$/.exec(String(code || '').trim().toUpperCase());
  if (!m) return false;
  const expected = Buffer.from(sign(m[1]));
  const given = Buffer.from(m[2]);
  return expected.length === given.length && crypto.timingSafeEqual(expected, given);
}
function normalizeCode(code) {
  return String(code || '').trim().toUpperCase();
}

// ---------- App ----------
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function requireAdmin(req, res, next) {
  const given = req.get('x-admin-password') || '';
  const a = Buffer.from(given);
  const b = Buffer.from(ADMIN_PASSWORD);
  if (a.length === b.length && crypto.timingSafeEqual(a, b)) return next();
  res.status(401).json({ error: 'Unauthorized' });
}

const wrap = fn => (req, res) => {
  try { fn(req, res); }
  catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
};

const round2 = n => Math.round(n * 100) / 100;

// ----- Auth check (used by UI login) -----
app.get('/api/auth', requireAdmin, (req, res) => res.json({ ok: true }));

// ----- Events -----
app.get('/api/events', requireAdmin, wrap((req, res) => {
  const rows = db.prepare(`
    SELECT e.*,
      (SELECT COUNT(*) FROM tickets t WHERE t.event_id = e.id AND t.status != 'cancelled') AS sold,
      (SELECT COUNT(*) FROM tickets t WHERE t.event_id = e.id AND t.status = 'used') AS checked_in
    FROM events e ORDER BY e.id DESC`).all();
  res.json(rows);
}));

app.post('/api/events', requireAdmin, wrap((req, res) => {
  const { name, venue, date, price, capacity } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });
  const info = db.prepare('INSERT INTO events (name, venue, date, price, capacity) VALUES (?,?,?,?,?)')
    .run(name, venue || '', date || '', Number(price) || 0, parseInt(capacity, 10) || 100);
  res.status(201).json(db.prepare('SELECT * FROM events WHERE id = ?').get(info.lastInsertRowid));
}));

// ----- Promoters -----
app.get('/api/promoters', requireAdmin, wrap((req, res) => {
  const rows = db.prepare(`
    SELECT p.*,
      COUNT(t.id) AS tickets_sold,
      COALESCE(SUM(t.price_paid), 0) AS revenue,
      COALESCE(SUM(t.price_paid), 0) * p.commission_percent / 100.0 AS commission_owed
    FROM promoters p
    LEFT JOIN tickets t ON t.promoter_id = p.id AND t.status != 'cancelled'
    GROUP BY p.id ORDER BY p.id DESC`).all();
  res.json(rows.map(r => ({ ...r, revenue: round2(r.revenue), commission_owed: round2(r.commission_owed) })));
}));

app.post('/api/promoters', requireAdmin, wrap((req, res) => {
  const { name, code, discount_percent, commission_percent, max_uses } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });
  const finalCode = normalizeCode(code) || `${name.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 6)}-${randomId(4)}`;
  const discount = Number(discount_percent) || 0;
  const commission = Number(commission_percent) || 0;
  if (discount < 0 || discount > 100 || commission < 0 || commission > 100)
    return res.status(400).json({ error: 'percentages must be between 0 and 100' });
  try {
    const info = db.prepare(`INSERT INTO promoters (name, code, discount_percent, commission_percent, max_uses)
      VALUES (?,?,?,?,?)`).run(name, finalCode, discount, commission, max_uses ? parseInt(max_uses, 10) : null);
    res.status(201).json(db.prepare('SELECT * FROM promoters WHERE id = ?').get(info.lastInsertRowid));
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'Promo code already exists' });
    throw e;
  }
}));

app.patch('/api/promoters/:id', requireAdmin, wrap((req, res) => {
  const { active } = req.body;
  db.prepare('UPDATE promoters SET active = ? WHERE id = ?').run(active ? 1 : 0, req.params.id);
  res.json({ ok: true });
}));

// Public: check a promo code (so a buyer-facing page can show the discount)
app.get('/api/promo/:code', wrap((req, res) => {
  const p = findUsablePromoter(normalizeCode(req.params.code));
  if (!p) return res.status(404).json({ error: 'Invalid or expired code' });
  res.json({ code: p.code, discount_percent: p.discount_percent });
}));

function findUsablePromoter(code) {
  if (!code) return null;
  const p = db.prepare('SELECT * FROM promoters WHERE code = ? AND active = 1').get(code);
  if (!p) return null;
  if (p.max_uses != null) {
    const used = db.prepare("SELECT COUNT(*) c FROM tickets WHERE promoter_id = ? AND status != 'cancelled'").get(p.id).c;
    if (used >= p.max_uses) return null;
  }
  return p;
}

// ----- Tickets -----
// Generate 1..50 tickets for an event, optionally with a promoter code.
app.post('/api/tickets', requireAdmin, wrap((req, res) => {
  const { event_id, quantity, holder_name, email, promo_code } = req.body;
  const qty = Math.min(Math.max(parseInt(quantity, 10) || 1, 1), 50);
  const event = db.prepare('SELECT * FROM events WHERE id = ?').get(event_id);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  let promoter = null;
  if (promo_code) {
    promoter = findUsablePromoter(normalizeCode(promo_code));
    if (!promoter) return res.status(400).json({ error: 'Invalid, inactive or exhausted promo code' });
  }

  const create = db.transaction(() => {
    const sold = db.prepare("SELECT COUNT(*) c FROM tickets WHERE event_id = ? AND status != 'cancelled'").get(event.id).c;
    if (sold + qty > event.capacity) {
      const err = new Error('Not enough capacity');
      err.status = 409;
      err.left = event.capacity - sold;
      throw err;
    }
    if (promoter && promoter.max_uses != null) {
      const used = db.prepare("SELECT COUNT(*) c FROM tickets WHERE promoter_id = ? AND status != 'cancelled'").get(promoter.id).c;
      if (used + qty > promoter.max_uses) {
        const err = new Error('Promo code usage limit would be exceeded');
        err.status = 409;
        throw err;
      }
    }
    const price = round2(event.price * (1 - (promoter ? promoter.discount_percent : 0) / 100));
    const insert = db.prepare(`INSERT INTO tickets (code, event_id, promoter_id, holder_name, email, price_paid)
      VALUES (?,?,?,?,?,?)`);
    const out = [];
    for (let i = 0; i < qty; i++) {
      const code = makeTicketCode();
      insert.run(code, event.id, promoter ? promoter.id : null, holder_name || '', email || '', price);
      out.push({ code, price_paid: price, event: event.name, promoter: promoter ? promoter.name : null });
    }
    return out;
  });

  try {
    res.status(201).json({ tickets: create() });
  } catch (e) {
    if (e.status) return res.status(e.status).json({ error: e.message, seats_left: e.left });
    throw e;
  }
}));

app.get('/api/events/:id/tickets', requireAdmin, wrap((req, res) => {
  const rows = db.prepare(`
    SELECT t.*, p.name AS promoter_name, p.code AS promo_code
    FROM tickets t LEFT JOIN promoters p ON p.id = t.promoter_id
    WHERE t.event_id = ? ORDER BY t.id DESC`).all(req.params.id);
  res.json(rows);
}));

app.post('/api/tickets/:code/cancel', requireAdmin, wrap((req, res) => {
  const info = db.prepare("UPDATE tickets SET status = 'cancelled' WHERE code = ? AND status = 'valid'")
    .run(normalizeCode(req.params.code));
  if (!info.changes) return res.status(409).json({ error: 'Ticket not found or not valid' });
  res.json({ ok: true });
}));

// QR image for a ticket (PNG). Public so it can be embedded in emails / PDFs,
// but the QR only contains the signed code, which is useless without the database.
app.get('/api/tickets/:code/qr.png', wrap(async (req, res) => {
  const code = normalizeCode(req.params.code);
  if (!verifyTicketCode(code)) return res.status(404).end();
  const png = await QRCode.toBuffer(code, { width: 400, margin: 2 });
  res.type('png').send(png);
}));

// ----- Check-in -----
// POST { code }. Marks the ticket as used the first time; later scans report "already used".
app.post('/api/check', requireAdmin, wrap((req, res) => {
  const code = normalizeCode(req.body.code);
  if (!verifyTicketCode(code)) {
    return res.json({ result: 'invalid', message: 'Not a valid ticket code' });
  }
  const ticket = db.prepare(`
    SELECT t.*, e.name AS event_name, p.name AS promoter_name
    FROM tickets t JOIN events e ON e.id = t.event_id
    LEFT JOIN promoters p ON p.id = t.promoter_id
    WHERE t.code = ?`).get(code);
  if (!ticket) return res.json({ result: 'invalid', message: 'Ticket not found' });
  if (ticket.status === 'cancelled') return res.json({ result: 'cancelled', message: 'Ticket was cancelled', ticket });

  // Atomic update: only the first scan flips valid -> used
  const info = db.prepare("UPDATE tickets SET status = 'used', used_at = datetime('now') WHERE code = ? AND status = 'valid'").run(code);
  if (info.changes === 0) {
    return res.json({ result: 'already_used', message: `Already used at ${ticket.used_at}`, ticket });
  }
  res.json({ result: 'ok', message: 'Valid - entry allowed', ticket: { ...ticket, status: 'used' } });
}));

// Look up without consuming (for a "peek" button)
app.get('/api/lookup/:code', requireAdmin, wrap((req, res) => {
  const code = normalizeCode(req.params.code);
  if (!verifyTicketCode(code)) return res.json({ result: 'invalid' });
  const ticket = db.prepare(`SELECT t.*, e.name AS event_name FROM tickets t JOIN events e ON e.id = t.event_id WHERE t.code = ?`).get(code);
  if (!ticket) return res.json({ result: 'invalid' });
  res.json({ result: ticket.status, ticket });
}));

if (require.main === module) {
  app.listen(PORT, () => console.log(`Ticketing app running on http://localhost:${PORT}`));
}
module.exports = app;
