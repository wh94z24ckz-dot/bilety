# Ticketing App

Generate tickets with signed QR codes, check them in at the door, and give promoters their own discount codes with sales and commission tracking.

Built with Node.js, Express and SQLite.

## Features

- Events with price and capacity
- Tickets with signed QR codes (forged codes are rejected)
- Door scanner page (camera or manual entry); a ticket works only once
- Promoter codes: discount %, commission %, max uses, enable/disable
- Per-promoter stats: tickets sold, revenue, commission owed

## Quick start

Requires Node.js 18+.

```bash
git clone https://github.com/<your-user>/ticketing-app.git
cd ticketing-app
npm install
cp .env.example .env   # then set values as environment variables (see below)
ADMIN_PASSWORD=your-password TICKET_SECRET=a-long-random-string npm start
```

Windows (PowerShell):

```powershell
$env:ADMIN_PASSWORD="your-password"; $env:TICKET_SECRET="a-long-random-string"; npm start
```

- Admin dashboard: http://localhost:3000/
- Door scanner: http://localhost:3000/scan.html

Data is stored in `tickets.db` (SQLite, ignored by git).

## Configuration

| Variable | Purpose |
|---|---|
| `ADMIN_PASSWORD` | Password for the admin dashboard and scanner |
| `TICKET_SECRET` | Signs ticket codes. Keep it stable: changing it invalidates existing tickets |
| `PORT` | Server port (default 3000) |
| `DB_FILE` | SQLite file path (default `./tickets.db`) |

## Test

```bash
npm test
```

## API

Admin endpoints need the header `x-admin-password`.

| Method | Path | Purpose |
|---|---|---|
| POST | /api/events | create event `{name, venue, date, price, capacity}` |
| GET | /api/events | list events with sold / checked-in counts |
| POST | /api/promoters | create promoter `{name, code?, discount_percent, commission_percent, max_uses?}` |
| GET | /api/promoters | promoters with sales stats |
| PATCH | /api/promoters/:id | enable/disable `{active}` |
| GET | /api/promo/:code | public: validate a code, returns discount |
| POST | /api/tickets | generate `{event_id, quantity, holder_name, email, promo_code?}` |
| GET | /api/events/:id/tickets | list tickets of an event |
| POST | /api/tickets/:code/cancel | cancel a valid ticket |
| GET | /api/tickets/:code/qr.png | public: QR image of a ticket |
| POST | /api/check | check in `{code}` |

## Deploying

This is a server app, so it can't run on GitHub Pages (static hosting only). Host it on a Node-capable service such as Render, Railway or Fly.io, set the environment variables above, and use persistent storage for `DB_FILE`. Serve it over HTTPS so phones can use the camera scanner.

## License

MIT
